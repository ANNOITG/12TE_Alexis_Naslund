﻿/// <reference path="../Scripts/jquery-ui-1.8.20.min.js" />

$(document).ready(function () {

    //run once
    var el = $('.social-float-parent');
    var originalelpos = el.offset().top; // take it where it originally is on the page

    //run on scroll
    $(window).scroll(function () {
        var el = $('.social-float-parent'); // important! (local)
        var elpos = el.offset().top; // take current situation
        var windowpos = $(window).scrollTop();
        var finaldestination = windowpos + originalelpos - 200;
        if (finaldestination > 200) {
            el.stop().animate({ 'top': finaldestination }, 500);
        }
        else {
            el.stop().animate({ 'top': 260 }, 500);
        }
    });

});