﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metoder_11_3
{
    class Program
    {
        static double Moms(int tal1)
        {
            double svar = tal1 * 1.25;
            return svar;
        }
        static void Main(string[] args)
        {
            
            int test = int.Parse(Console.ReadLine());
            double momsSvar = Moms(test);
            Console.WriteLine(momsSvar);

            


            Console.ReadKey();
        }
    }
}
