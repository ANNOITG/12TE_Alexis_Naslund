﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metoder_11_1
{
    class Program
    {
        static void Hello(string var1)
        {
            Console.WriteLine("Hej " + var1);
        }
        static void Main(string[] args)
        {

            string name = Console.ReadLine();

            Hello(name);


            Console.ReadKey();
        }
    }
}
