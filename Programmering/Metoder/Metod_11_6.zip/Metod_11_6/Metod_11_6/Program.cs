﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metod_11_6
{
    class Program
    {
        static int Moms(double tal1)
        {
            double svar = tal1 * 100;
            return (int)svar;
        }
        static void Main(string[] args)
        {

            double test = double.Parse(Console.ReadLine());
            int momsSvar = Moms(test);
            Console.WriteLine(momsSvar);




            Console.ReadKey();
        }
    }
}
