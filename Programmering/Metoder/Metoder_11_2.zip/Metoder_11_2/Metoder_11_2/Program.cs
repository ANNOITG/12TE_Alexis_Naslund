﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metoder_11_2
{
    class Program
    {
        static void Hello(string var1)
        {
            Console.WriteLine(var1);
        }
        static void Main(string[] args)
        {

            string name = Console.ReadLine();
            string name1 = Console.ReadLine();

            Hello(name + name1);


            Console.ReadKey();
        }
    }
}
