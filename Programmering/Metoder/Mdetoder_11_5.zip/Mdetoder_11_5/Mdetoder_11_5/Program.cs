﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mdetoder_11_5
{
    class Program
    {
        static double Moms(int test1,double test2)
        {
            double svar = (test1 * test2);
            return svar;
        }
        static void Main(string[] args)
        {

            int test1 = int.Parse(Console.ReadLine());
            double test2 = double.Parse(Console.ReadLine());
            double momsSvar = Moms(test1, test2);
            Console.WriteLine(momsSvar);




            Console.ReadKey();
        }
    }
}
