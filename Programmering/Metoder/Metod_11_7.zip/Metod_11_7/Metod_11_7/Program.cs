﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metod_11_7
{
    class Program
    {
        static bool myndig(int alder)
        {
            if (alder >= 18)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static void Main(string[] args)
        {

            int alder = int.Parse(Console.ReadLine());
            if (myndig(alder))
            {
                Console.WriteLine("Du är myndig");
            }
            else
            {
                Console.WriteLine("Du är minderårig");
            }




            Console.ReadKey();
        }
    }
}
