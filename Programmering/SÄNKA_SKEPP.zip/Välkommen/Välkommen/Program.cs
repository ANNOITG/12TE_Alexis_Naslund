﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Välkommen
{
    class Program
    {
        static void Welcome(string name)
        {
            Console.WriteLine("");
            Console.WriteLine("====== VÄLKOMEN TILL SÄNKA SKEPP! ======");
        }
        public static void WriteBoard()
        {
            for (int y = 0; y < 10; y++)
            {
                Console.WriteLine("-----------------------------------------");
                Console.Write("| ");

                for (int x = 0; x < 10; x++)
                {
                    if (spelplan[x, y] == "*")
                    {
                        Console.Write("# | ");
                    }
                    else
                    {
                        Console.Write(spelplan[x, y] + " | ");
                    }
                }
                Console.WriteLine("");
            }
            Console.WriteLine("-----------------------------------------");
        }
        public static void CreateBoard()
        {
            for (int y = 0; y < 10; y++)
            {
               

                for (int x = 0; x < 10; x++)
                {
                    spelplan[x, y] = "#";   
                }
            }
            
            //// SLUT PÅ SPELPLAN

            // ALLA FARTYGEN
            spelplan[0, 0] = "*";
            spelplan[0, 2] = "*";
            spelplan[7, 1] = "*";
            spelplan[5, 2] = "*";
            spelplan[9, 2] = "*";
            // SLUT PÅ FARTYG

        }
        public static bool shoot()
        {
            int svarX = 0;
            int svarY = 0;
            bool loop = true;
            do
            {

                Console.WriteLine("=======Skriv in X koordinaterna!=======");
                string strX = Console.ReadLine();
                Console.WriteLine("=======Skriv in Y koordinaterna!=======");
                string strY = Console.ReadLine();

                try
                {
                    svarX = Convert.ToInt32(strX);
                    svarY = Convert.ToInt32(strY);
                    loop = false;
                }
                catch
                {
                    Console.WriteLine("Skriv in en siffra, inte tal.");
                }
            } while (loop);

            if (spelplan[svarX, svarY] == "*")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                spelplan[svarX, svarY] = "X";
                Console.WriteLine("======Träff=====");
                Console.ResetColor();
                return true;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                spelplan[svarX, svarY] = "O";
                Console.WriteLine("=====Miss=====");
                Console.ResetColor();
                return false;
            }
        }
        public static string[,] spelplan = new string[10, 10];
        static void Main(string[] args)
        {
            CreateBoard();
            Welcome("User");
            Console.WriteLine();

            while (true)
            {

                //MENYEN
                Console.WriteLine("MENY");
                Console.WriteLine("[B]örja");
                Console.WriteLine("[I]struktioner");
                Console.WriteLine("[A]vbryt");
                Console.WriteLine("");
                Console.WriteLine("========================================");

                string menySelection = Console.ReadLine();

                if (menySelection == "B" || menySelection == "b")
                {
                    
                    // Koden här
                    // UPPRITAD SPELPLAN

                    //==Välja svårighet==
                    Console.WriteLine("====SVÅRHETSGRAD====");
                    Console.WriteLine("");
                    Console.WriteLine("[E]ASY = 30 FÖRSÖK");
                    Console.WriteLine("[M]EDIUM = 15 FÖRSÖK");
                    Console.WriteLine("[H]ARD = 10 FÖRSÖK");
                    Console.WriteLine(" ");
                    Console.WriteLine("====================");

                    menySelection = Console.ReadLine();

                    if (menySelection == "E" || menySelection == "e")
                    {
                        for (int i = 1; i <= 30; i++)
                        {
                            WriteBoard();
                            shoot();
                        }
                    }

                    if (menySelection == "M" || menySelection == "m")
                    {
                        for (int i = 1; i <= 15; i++)
                        {
                            WriteBoard();
                            shoot();
                        }
                    }
                    if (menySelection == "H" || menySelection == "h")
                    {
                        for (int i = 1; i <= 10; i++)
                        {
                            WriteBoard();
                            shoot();
                            
                        }
                    }
                    
                    

                    
                    
                    
                    
                    




                    //Slut på koden.
                }
                else if (menySelection == "I" || menySelection == "i")
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("=====INSTRUKTIONER=====");
                    //Kod för instruktion
                    Console.WriteLine("");
                    Console.WriteLine("§ Du kommer välja mellan 3 olika svårhetsgrader");
                    Console.WriteLine(" | EASY - 30 försök");
                    Console.WriteLine(" | MEDIUM - 15 försök");
                    Console.WriteLine(" | HARD - 10 försök");
                    Console.WriteLine("§ '#' är oskjuten koordinaterna");
                    Console.WriteLine("§ 'X' är träff.");
                    Console.WriteLine("§ 'O' är miss.");
                    Console.WriteLine("§ Datorn svarar ifall du träffar elle missar");
                    Console.WriteLine("§ Du får inte gissa samma kordinater 2ggr.");
                    Console.WriteLine("§ När alla 5 platser är träffade så vinner du. ");
                    Console.WriteLine("§ Ha kul!");
                    Console.WriteLine("");
                    Console.WriteLine("=======================");
                    Console.ResetColor();

                }
                else if (menySelection == "A" || menySelection == "a")
                {
                    Console.WriteLine("Hej då pappa, Ha de bra! Ses på hotellet sen");
                    Console.WriteLine("Hoppas du är snäll mot dina kunder som du lovade.");
                    break;
                }

            }





            Console.ReadKey();

        }
    }
}
