﻿namespace Alexis_Egna_Försök
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CarBS = new System.Windows.Forms.BindingSource(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.CarSearchTbx = new System.Windows.Forms.TextBox();
            this.carSokBtn = new System.Windows.Forms.Button();
            this.carAndraBtn = new System.Windows.Forms.Button();
            this.carRaderaBtn = new System.Windows.Forms.Button();
            this.carSparaBtn = new System.Windows.Forms.Button();
            this.carBoultPatternTbx = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.FuelNameTbx = new System.Windows.Forms.TextBox();
            this.YearNameTbx = new System.Windows.Forms.TextBox();
            this.ModellNameTbx = new System.Windows.Forms.TextBox();
            this.CarNameTbx = new System.Windows.Forms.TextBox();
            this.CarDGV = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.WheelRaderaBtn = new System.Windows.Forms.Button();
            this.wheelAddBtn = new System.Windows.Forms.Button();
            this.CarCbx = new System.Windows.Forms.ComboBox();
            this.Wheel_ModellTbx = new System.Windows.Forms.TextBox();
            this.Wheel_PriceTbx = new System.Windows.Forms.TextBox();
            this.Wheel_NameTbx = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.WheelDGV = new System.Windows.Forms.DataGridView();
            this.WheelBS = new System.Windows.Forms.BindingSource(this.components);
            this.wheelAndraBtn = new System.Windows.Forms.Button();
            this.wheelSokBtn = new System.Windows.Forms.Button();
            this.wheelSokTbx = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.CarBS)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CarDGV)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WheelDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WheelBS)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(536, 402);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.CarSearchTbx);
            this.tabPage1.Controls.Add(this.carSokBtn);
            this.tabPage1.Controls.Add(this.carAndraBtn);
            this.tabPage1.Controls.Add(this.carRaderaBtn);
            this.tabPage1.Controls.Add(this.carSparaBtn);
            this.tabPage1.Controls.Add(this.carBoultPatternTbx);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.FuelNameTbx);
            this.tabPage1.Controls.Add(this.YearNameTbx);
            this.tabPage1.Controls.Add(this.ModellNameTbx);
            this.tabPage1.Controls.Add(this.CarNameTbx);
            this.tabPage1.Controls.Add(this.CarDGV);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(528, 376);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Bilar";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // CarSearchTbx
            // 
            this.CarSearchTbx.Location = new System.Drawing.Point(116, 347);
            this.CarSearchTbx.Name = "CarSearchTbx";
            this.CarSearchTbx.Size = new System.Drawing.Size(206, 20);
            this.CarSearchTbx.TabIndex = 31;
            // 
            // carSokBtn
            // 
            this.carSokBtn.Location = new System.Drawing.Point(10, 345);
            this.carSokBtn.Name = "carSokBtn";
            this.carSokBtn.Size = new System.Drawing.Size(100, 23);
            this.carSokBtn.TabIndex = 30;
            this.carSokBtn.Text = "Sök";
            this.carSokBtn.UseVisualStyleBackColor = true;
            this.carSokBtn.Click += new System.EventHandler(this.carSokBtn_Click);
            // 
            // carAndraBtn
            // 
            this.carAndraBtn.Location = new System.Drawing.Point(116, 314);
            this.carAndraBtn.Name = "carAndraBtn";
            this.carAndraBtn.Size = new System.Drawing.Size(100, 23);
            this.carAndraBtn.TabIndex = 29;
            this.carAndraBtn.Text = "Ändra";
            this.carAndraBtn.UseVisualStyleBackColor = true;
            this.carAndraBtn.Click += new System.EventHandler(this.carAndraBtn_Click);
            // 
            // carRaderaBtn
            // 
            this.carRaderaBtn.Location = new System.Drawing.Point(222, 316);
            this.carRaderaBtn.Name = "carRaderaBtn";
            this.carRaderaBtn.Size = new System.Drawing.Size(100, 23);
            this.carRaderaBtn.TabIndex = 28;
            this.carRaderaBtn.Text = "Radera";
            this.carRaderaBtn.UseVisualStyleBackColor = true;
            this.carRaderaBtn.Click += new System.EventHandler(this.carRaderaBtn_Click);
            // 
            // carSparaBtn
            // 
            this.carSparaBtn.Location = new System.Drawing.Point(10, 314);
            this.carSparaBtn.Name = "carSparaBtn";
            this.carSparaBtn.Size = new System.Drawing.Size(100, 23);
            this.carSparaBtn.TabIndex = 27;
            this.carSparaBtn.Text = "Spara";
            this.carSparaBtn.UseVisualStyleBackColor = true;
            this.carSparaBtn.Click += new System.EventHandler(this.carSparaBtn_Click);
            // 
            // carBoultPatternTbx
            // 
            this.carBoultPatternTbx.Location = new System.Drawing.Point(418, 214);
            this.carBoultPatternTbx.Name = "carBoultPatternTbx";
            this.carBoultPatternTbx.Size = new System.Drawing.Size(100, 20);
            this.carBoultPatternTbx.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(350, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "Bultmönster";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(185, 246);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Bränsle:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(178, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 23;
            this.label3.Text = "Årsmodell";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 243);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Modell";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 217);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Car Name";
            // 
            // FuelNameTbx
            // 
            this.FuelNameTbx.Location = new System.Drawing.Point(236, 243);
            this.FuelNameTbx.Name = "FuelNameTbx";
            this.FuelNameTbx.Size = new System.Drawing.Size(100, 20);
            this.FuelNameTbx.TabIndex = 20;
            // 
            // YearNameTbx
            // 
            this.YearNameTbx.Location = new System.Drawing.Point(236, 214);
            this.YearNameTbx.Name = "YearNameTbx";
            this.YearNameTbx.Size = new System.Drawing.Size(100, 20);
            this.YearNameTbx.TabIndex = 19;
            // 
            // ModellNameTbx
            // 
            this.ModellNameTbx.Location = new System.Drawing.Point(72, 240);
            this.ModellNameTbx.Name = "ModellNameTbx";
            this.ModellNameTbx.Size = new System.Drawing.Size(100, 20);
            this.ModellNameTbx.TabIndex = 18;
            // 
            // CarNameTbx
            // 
            this.CarNameTbx.Location = new System.Drawing.Point(72, 214);
            this.CarNameTbx.Name = "CarNameTbx";
            this.CarNameTbx.Size = new System.Drawing.Size(100, 20);
            this.CarNameTbx.TabIndex = 17;
            // 
            // CarDGV
            // 
            this.CarDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CarDGV.Location = new System.Drawing.Point(10, 8);
            this.CarDGV.Name = "CarDGV";
            this.CarDGV.Size = new System.Drawing.Size(508, 184);
            this.CarDGV.TabIndex = 16;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.wheelSokTbx);
            this.tabPage2.Controls.Add(this.wheelSokBtn);
            this.tabPage2.Controls.Add(this.wheelAndraBtn);
            this.tabPage2.Controls.Add(this.WheelRaderaBtn);
            this.tabPage2.Controls.Add(this.wheelAddBtn);
            this.tabPage2.Controls.Add(this.CarCbx);
            this.tabPage2.Controls.Add(this.Wheel_ModellTbx);
            this.tabPage2.Controls.Add(this.Wheel_PriceTbx);
            this.tabPage2.Controls.Add(this.Wheel_NameTbx);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.WheelDGV);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(528, 376);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Däck";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // WheelRaderaBtn
            // 
            this.WheelRaderaBtn.Location = new System.Drawing.Point(128, 313);
            this.WheelRaderaBtn.Name = "WheelRaderaBtn";
            this.WheelRaderaBtn.Size = new System.Drawing.Size(95, 23);
            this.WheelRaderaBtn.TabIndex = 10;
            this.WheelRaderaBtn.Text = "Radera";
            this.WheelRaderaBtn.UseVisualStyleBackColor = true;
            this.WheelRaderaBtn.Click += new System.EventHandler(this.WheelRaderaBtn_Click);
            // 
            // wheelAddBtn
            // 
            this.wheelAddBtn.Location = new System.Drawing.Point(27, 313);
            this.wheelAddBtn.Name = "wheelAddBtn";
            this.wheelAddBtn.Size = new System.Drawing.Size(95, 23);
            this.wheelAddBtn.TabIndex = 9;
            this.wheelAddBtn.Text = "Spara";
            this.wheelAddBtn.UseVisualStyleBackColor = true;
            this.wheelAddBtn.Click += new System.EventHandler(this.wheelAddBtn_Click);
            // 
            // CarCbx
            // 
            this.CarCbx.FormattingEnabled = true;
            this.CarCbx.Location = new System.Drawing.Point(234, 274);
            this.CarCbx.Name = "CarCbx";
            this.CarCbx.Size = new System.Drawing.Size(121, 21);
            this.CarCbx.TabIndex = 8;
            // 
            // Wheel_ModellTbx
            // 
            this.Wheel_ModellTbx.Location = new System.Drawing.Point(68, 274);
            this.Wheel_ModellTbx.Name = "Wheel_ModellTbx";
            this.Wheel_ModellTbx.Size = new System.Drawing.Size(100, 20);
            this.Wheel_ModellTbx.TabIndex = 7;
            // 
            // Wheel_PriceTbx
            // 
            this.Wheel_PriceTbx.Location = new System.Drawing.Point(234, 235);
            this.Wheel_PriceTbx.Name = "Wheel_PriceTbx";
            this.Wheel_PriceTbx.Size = new System.Drawing.Size(121, 20);
            this.Wheel_PriceTbx.TabIndex = 6;
            // 
            // Wheel_NameTbx
            // 
            this.Wheel_NameTbx.Location = new System.Drawing.Point(65, 235);
            this.Wheel_NameTbx.Name = "Wheel_NameTbx";
            this.Wheel_NameTbx.Size = new System.Drawing.Size(100, 20);
            this.Wheel_NameTbx.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(174, 277);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Passar till:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(197, 238);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Price";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 238);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 277);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Modell";
            // 
            // WheelDGV
            // 
            this.WheelDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.WheelDGV.Location = new System.Drawing.Point(6, 3);
            this.WheelDGV.Name = "WheelDGV";
            this.WheelDGV.Size = new System.Drawing.Size(516, 208);
            this.WheelDGV.TabIndex = 0;
            // 
            // wheelAndraBtn
            // 
            this.wheelAndraBtn.Location = new System.Drawing.Point(229, 313);
            this.wheelAndraBtn.Name = "wheelAndraBtn";
            this.wheelAndraBtn.Size = new System.Drawing.Size(95, 23);
            this.wheelAndraBtn.TabIndex = 11;
            this.wheelAndraBtn.Text = "Ändra";
            this.wheelAndraBtn.UseVisualStyleBackColor = true;
            this.wheelAndraBtn.Click += new System.EventHandler(this.wheelAndraBtn_Click);
            // 
            // wheelSokBtn
            // 
            this.wheelSokBtn.Location = new System.Drawing.Point(27, 342);
            this.wheelSokBtn.Name = "wheelSokBtn";
            this.wheelSokBtn.Size = new System.Drawing.Size(95, 23);
            this.wheelSokBtn.TabIndex = 12;
            this.wheelSokBtn.Text = "Sök";
            this.wheelSokBtn.UseVisualStyleBackColor = true;
            this.wheelSokBtn.Click += new System.EventHandler(this.wheelSokBtn_Click);
            // 
            // wheelSokTbx
            // 
            this.wheelSokTbx.Location = new System.Drawing.Point(128, 344);
            this.wheelSokTbx.Name = "wheelSokTbx";
            this.wheelSokTbx.Size = new System.Drawing.Size(196, 20);
            this.wheelSokTbx.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 405);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CarBS)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CarDGV)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WheelDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WheelBS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource CarBS;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox CarSearchTbx;
        private System.Windows.Forms.Button carSokBtn;
        private System.Windows.Forms.Button carAndraBtn;
        private System.Windows.Forms.Button carRaderaBtn;
        private System.Windows.Forms.Button carSparaBtn;
        private System.Windows.Forms.TextBox carBoultPatternTbx;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox FuelNameTbx;
        private System.Windows.Forms.TextBox YearNameTbx;
        private System.Windows.Forms.TextBox ModellNameTbx;
        private System.Windows.Forms.TextBox CarNameTbx;
        private System.Windows.Forms.DataGridView CarDGV;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button wheelAddBtn;
        private System.Windows.Forms.ComboBox CarCbx;
        private System.Windows.Forms.TextBox Wheel_ModellTbx;
        private System.Windows.Forms.TextBox Wheel_PriceTbx;
        private System.Windows.Forms.TextBox Wheel_NameTbx;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView WheelDGV;
        private System.Windows.Forms.BindingSource WheelBS;
        private System.Windows.Forms.Button WheelRaderaBtn;
        private System.Windows.Forms.Button wheelAndraBtn;
        private System.Windows.Forms.TextBox wheelSokTbx;
        private System.Windows.Forms.Button wheelSokBtn;
    }
}

