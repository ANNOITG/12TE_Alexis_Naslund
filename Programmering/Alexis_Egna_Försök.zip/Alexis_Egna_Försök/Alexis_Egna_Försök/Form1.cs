﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Alexis_Egna_Försök
{
    public partial class Form1 : Form
    {
        CarToWheelDataContext db = new CarToWheelDataContext();

        public Form1()
        {
            InitializeComponent();
        }
        //========BÖRJAN AV FÖRSTA QUARY================
        private void Form1_Load(object sender, EventArgs e)
        {
            WheelDGV.DataSource = WheelBS;
            WheelBS.DataSource = from i in db.Wheels
                                 orderby i.Wheel_Name
                                 select i;
            CarCbx.DataSource = from data in db.Cars
                                orderby data.Car_Wheel
                                select data;
            CarCbx.ValueMember = "Car_ID";
            CarCbx.DisplayMember = "Car_Name";


            CarDGV.DataSource = CarBS;
            CarBS.DataSource = from data in db.Cars
                               orderby data.Car_Name
                               select data;
        }
        //===SPARA "KOD"===
        private void carSparaBtn_Click(object sender, EventArgs e)
        {
            Car b = new Car();

            try
            {
                b.Car_Name = CarNameTbx.Text;
                b.Car_Modell = ModellNameTbx.Text;
                b.Car_Year = YearNameTbx.Text;
                b.Car_Fuel = FuelNameTbx.Text;
                b.Car_Wheel = carBoultPatternTbx.Text;

                db.Cars.InsertOnSubmit(b);
                db.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            CarBS.DataSource = from data in db.Cars
                               orderby data.Car_Name
                               select data;
            CarCbx.DataSource = from data in db.Cars
                                orderby data.Car_Name
                                select data;
        }
        //===RADERA "KOD"===
        private void carRaderaBtn_Click(object sender, EventArgs e)
        {
            if (CarDGV.SelectedRows.Count == 1)
            {
                int selected_id = (int)CarDGV.SelectedRows[0].Cells[0].Value;

                Car b = db.Cars.Single(car => car.Car_ID == selected_id);

                db.Cars.DeleteOnSubmit(b);
                db.SubmitChanges();

                CarBS.DataSource = from data in db.Cars
                                   select data;
            }
        }
        //===ÄNDRA "KOD"===
        int CarState = 0;
        int tempID;
        private void carAndraBtn_Click(object sender, EventArgs e)
        {
            if (CarState == 0)
            {
                if (CarDGV.SelectedRows.Count == 1)
                {
                    int selected_id = (int)CarDGV.SelectedRows[0].Cells[0].Value;

                    Car b = db.Cars.Single(car => car.Car_ID == selected_id);

                    tempID = b.Car_ID;
                    CarNameTbx.Text = b.Car_Name;
                    ModellNameTbx.Text = b.Car_Modell;
                    YearNameTbx.Text = b.Car_Year;
                    FuelNameTbx.Text = b.Car_Fuel;
                    carBoultPatternTbx.Text = b.Car_Wheel;

                    CarState = 1;
                }
            }
            else
            {
                try
                {
                    Car b = db.Cars.Single(car => car.Car_ID == tempID);
                    b.Car_Name = CarNameTbx.Text;
                    b.Car_Modell = ModellNameTbx.Text;
                    b.Car_Year = YearNameTbx.Text;
                    b.Car_Fuel = FuelNameTbx.Text;
                    b.Car_Wheel = carBoultPatternTbx.Text;

                    db.SubmitChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                CarState = 0;
            }

        }
        //===SÖK "KOD"===
        private void carSokBtn_Click(object sender, EventArgs e)
        {
            if (CarSearchTbx.Text.Trim().Length > 0) //Sök-ordet måste vara större än 0.
            {
                string SokWord = CarSearchTbx.Text.Trim().ToLower();

                var SokResultat = from result in db.Cars
                                  where result.Car_ID.ToString().Contains(SokWord)
                                  || result.Car_Name.ToLower().Contains(SokWord)
                                  || result.Car_Modell.ToLower().Contains(SokWord)
                                  || result.Car_Year.ToLower().Contains(SokWord)
                                  || result.Car_Fuel.ToLower().Contains(SokWord)
                                  || result.Car_Wheel.ToLower().Contains(SokWord)
                                  orderby result.Car_Name
                                  select result;

                CarBS.DataSource = SokResultat;
            }
            else
            {
                CarBS.DataSource = from data in db.Cars
                                   orderby data.Car_ID
                                   select data;
            }
        }
        //=========SLUT PÅ FÖRSTA QUARY===============



        //========BÖRJAN AV ANDRA QUARY===============
        //===Lägga-till Koden===
        private void wheelAddBtn_Click(object sender, EventArgs e)
        {
            Wheel b = new Wheel();

            try 
            {
                if(Wheel_NameTbx.Text.Length > 0)
                {
                    b.Wheel_Name = Wheel_NameTbx.Text;
                    b.Car = (int)CarCbx.SelectedValue;
                    b.Wheel_Modell = Wheel_ModellTbx.Text;
                    b.Wheel_Price = int.Parse(Wheel_PriceTbx.Text);

                    db.Wheels.InsertOnSubmit(b);
                    db.SubmitChanges();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            WheelBS.DataSource = from data in db.Wheels
                                 select data;
        }
        //===Radera koden===
        private void WheelRaderaBtn_Click(object sender, EventArgs e)
        {
            if (WheelDGV.SelectedRows.Count == 1)
            {
                int selected_id = (int)WheelDGV.SelectedRows[0].Cells[0].Value;

                Wheel b = db.Wheels.Single(wheel => wheel.Wheel_ID == selected_id);

                db.Wheels.DeleteOnSubmit(b);
                db.SubmitChanges();
                WheelBS.DataSource = from data in db.Wheels
                                     select data;
            }
        }
        //===Ändra koden===
        int DackTI = 0;
        int DackCS = 0;
        private void wheelAndraBtn_Click(object sender, EventArgs e)
        {
            if (DackCS == 0)
            {
                if (WheelDGV.SelectedRows.Count == 1)
                {
                    int selected_id = (int)WheelDGV.SelectedRows[0].Cells[0].Value;

                    Wheel b = db.Wheels.Single(wheel => wheel.Wheel_ID == selected_id);

                    DackTI = b.Wheel_ID;
                    Wheel_NameTbx.Text = b.Wheel_Name;
                    Wheel_ModellTbx.Text = b.Wheel_Modell;
                    Wheel_PriceTbx.Text = b.Wheel_Price.ToString();

                    DackCS = 1;
                }
            }
            else
            {
                try
                {
                    Wheel b = db.Wheels.Single(wheel => wheel.Wheel_ID == DackTI);
                    b.Wheel_Name = Wheel_NameTbx.Text;
                    b.Wheel_Modell = Wheel_ModellTbx.Text;
                    b.Wheel_Price = int.Parse(Wheel_PriceTbx.Text);

                    db.SubmitChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                DackCS = 0;
            }
        }
        //=== Sök koden===
        private void wheelSokBtn_Click(object sender, EventArgs e)
        {
            if (wheelSokTbx.Text.Trim().Length > 0) //===Sökordet ska vara längre än 1===
            {
                string sokWordWheel = wheelSokTbx.Text.Trim().ToLower();
                var sokReslutWheel = from wheelResult in db.Wheels
                                     where wheelResult.Wheel_ID.ToString().Contains(sokWordWheel)
                                     || wheelResult.Wheel_Name.ToLower().Contains(sokWordWheel)
                                     || wheelResult.Wheel_Modell.ToLower().Contains(sokWordWheel)
                                     || wheelResult.Wheel_Price.ToString().Contains(sokWordWheel)
                                     orderby wheelResult.Wheel_Name
                                     select wheelResult;
                WheelBS.DataSource = sokReslutWheel;
            }
            else
            {
                WheelBS.DataSource = from data in db.Wheels
                                     orderby data.Wheel_Name
                                     select data;
            }
        }
        //=======SLUT PÅ ANDRA QUARY==================

        

        
        

    }
}
