﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TALA_TILL_MIG_BUGFRI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hejsan!"); //====================================="Användaren är ========================
            Console.WriteLine("Skriv in 2 olika siffror som ska adderas");//=====dum i huvudet" - Anno==============
            int tal1; //====Skapar int variabel======
            while (true) //====Skapar loop som kommer forstätta ifall try-catch crashar=============
            {
                try //=========skapandet av try-catch=======
                {
                    tal1 = int.Parse(Console.ReadLine());//=====Användaren skriver in variablen======
                    break;
                }
                catch
                {

                }
            }
            int tal2;//=====Se tidigare=======
            while (true)//====Se tidigare======
            {
                try
                {
                    tal2 = int.Parse(Console.ReadLine());//=====Se tidigare======
                    break;
                }
                catch
                {

                }
            }
            int svar1 = (tal1 + tal2); //===== Adderar dom två talen till en summa, för mindre skrivande till WriteLine====
            Console.WriteLine("Adderad: " + svar1); 
            Console.WriteLine("Skriv in ett ytterligare tal som ska subtrahera");

            int tal3;//====Skapar ännu en variabel=====
            while (true)
            {
                try
                {
                    tal3 = int.Parse(Console.ReadLine());
                    break;
                }
                catch
                {

                }
            }

            int svar2 = (svar1 - tal3);
            Console.WriteLine("Svar: " + svar2);
            Console.WriteLine("Skriv in ett tal till som ska Multiplicera ");
            int tal4;
            while (true)
            {
                try
                {
                    tal4 = int.Parse(Console.ReadLine());
                    break;
                }
                catch
                {

                }
            }
            int svar3 = (svar2 * tal4);
            Console.WriteLine("Multiplikation: " + svar3);
            Console.WriteLine("Skriv in ett tal till som ska dividera");
            int tal5;
            while (true)
            {
                try
                {
                    tal5 = int.Parse(Console.ReadLine());
                    break;
                }
                catch
                {

                }
            }
            int svar4 = (svar3 / tal5);
            Console.WriteLine("Dividera: " + svar4);



            Console.ReadKey();
        }
    }
}
