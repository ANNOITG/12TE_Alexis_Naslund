﻿namespace LINQ_2
{
    partial class BS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bandDGV = new System.Windows.Forms.DataGridView();
            this.bandBS = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bandDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bandBS)).BeginInit();
            this.SuspendLayout();
            // 
            // bandDGV
            // 
            this.bandDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bandDGV.Location = new System.Drawing.Point(12, 12);
            this.bandDGV.Name = "bandDGV";
            this.bandDGV.Size = new System.Drawing.Size(670, 276);
            this.bandDGV.TabIndex = 0;
            this.bandDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bandDGV_CellContentClick);
            // 
            // BS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 300);
            this.Controls.Add(this.bandDGV);
            this.Name = "BS";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bandDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bandBS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView bandDGV;
        private System.Windows.Forms.BindingSource bandBS;
    }
}

