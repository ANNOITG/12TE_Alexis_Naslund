﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ_2
{
    public partial class BS : Form
    {
        public BS()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            bandDGV.DataSource = bandDGV;
            bandBS.DataSource = from data in db.Bands
                                select data;
        }

        private void bandDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
