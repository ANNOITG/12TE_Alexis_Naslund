﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1_Link_Tutorail
{
    public partial class Form1 : Form
    {
        DataClasses2DataContext db = new DataClasses2DataContext();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //MessageBox.Show(db.Connection.Database);
            bandDGV.DataSource = bandBS;
            bandBS.DataSource = from data in db.Bands
                                select data;
        }
        private void bandAddBtn_Click(object sender, EventArgs e)
        {
            Band b = new Band();

            try
            {
                b.Band_Name = bandNameTbx.Text;
                b.Members = int.Parse(bandCountTbx.Text);
                b.From_Location = BandFromTbx.Text;
                b.Info = bandInfoTbx.Text;
                b.Startyear = bandStartYearTbx.Text;

                db.Bands.InsertOnSubmit(b);
                db.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            bandBS.DataSource = from data in db.Bands
                                select data;
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void bandRemoveBtn_Click(object sender, EventArgs e)
        {
            if (bandDGV.SelectedRows.Count == 1)
            {
                int selected_id = (int)bandDGV.SelectedRows[0].Cells[0].Value;

                Band b = db.Bands.Single(band => band.Band_ID == selected_id);

                db.Bands.DeleteOnSubmit(b);
                db.SubmitChanges();
                bandBS.DataSource = from data in db.Bands
                                    select data;
            }
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
    }
}
