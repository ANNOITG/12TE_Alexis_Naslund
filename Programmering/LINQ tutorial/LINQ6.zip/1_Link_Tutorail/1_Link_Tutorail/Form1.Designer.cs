﻿namespace _1_Link_Tutorail
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bandBS = new System.Windows.Forms.BindingSource(this.components);
            this.bandDGV = new System.Windows.Forms.DataGridView();
            this.bandAddBtn = new System.Windows.Forms.Button();
            this.bandNameTbx = new System.Windows.Forms.TextBox();
            this.bandCountTbx = new System.Windows.Forms.TextBox();
            this.BandFromTbx = new System.Windows.Forms.TextBox();
            this.bandNameLbl = new System.Windows.Forms.Label();
            this.bandCountLbl = new System.Windows.Forms.Label();
            this.BandFromLbl = new System.Windows.Forms.Label();
            this.bandInfoLbl = new System.Windows.Forms.Label();
            this.bandInfoTbx = new System.Windows.Forms.TextBox();
            this.bandStartYearLbl = new System.Windows.Forms.Label();
            this.bandStartYearTbx = new System.Windows.Forms.TextBox();
            this.BandRemoveBtn = new System.Windows.Forms.Button();
            this.bandChangeBtn = new System.Windows.Forms.Button();
            this.bandSrchTbx = new System.Windows.Forms.TextBox();
            this.BandSrchBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bandBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bandDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // bandDGV
            // 
            this.bandDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bandDGV.Location = new System.Drawing.Point(16, 30);
            this.bandDGV.Name = "bandDGV";
            this.bandDGV.Size = new System.Drawing.Size(455, 180);
            this.bandDGV.TabIndex = 0;
            // 
            // bandAddBtn
            // 
            this.bandAddBtn.Location = new System.Drawing.Point(16, 342);
            this.bandAddBtn.Name = "bandAddBtn";
            this.bandAddBtn.Size = new System.Drawing.Size(80, 23);
            this.bandAddBtn.TabIndex = 1;
            this.bandAddBtn.Text = "Save";
            this.bandAddBtn.UseVisualStyleBackColor = true;
            this.bandAddBtn.Click += new System.EventHandler(this.bandAddBtn_Click);
            // 
            // bandNameTbx
            // 
            this.bandNameTbx.Location = new System.Drawing.Point(102, 228);
            this.bandNameTbx.Name = "bandNameTbx";
            this.bandNameTbx.Size = new System.Drawing.Size(100, 20);
            this.bandNameTbx.TabIndex = 2;
            this.bandNameTbx.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // bandCountTbx
            // 
            this.bandCountTbx.Location = new System.Drawing.Point(273, 254);
            this.bandCountTbx.Name = "bandCountTbx";
            this.bandCountTbx.Size = new System.Drawing.Size(100, 20);
            this.bandCountTbx.TabIndex = 3;
            // 
            // BandFromTbx
            // 
            this.BandFromTbx.Location = new System.Drawing.Point(102, 255);
            this.BandFromTbx.Name = "BandFromTbx";
            this.BandFromTbx.Size = new System.Drawing.Size(100, 20);
            this.BandFromTbx.TabIndex = 4;
            // 
            // bandNameLbl
            // 
            this.bandNameLbl.AutoSize = true;
            this.bandNameLbl.Location = new System.Drawing.Point(37, 231);
            this.bandNameLbl.Name = "bandNameLbl";
            this.bandNameLbl.Size = new System.Drawing.Size(63, 13);
            this.bandNameLbl.TabIndex = 5;
            this.bandNameLbl.Text = "Band Namn";
            // 
            // bandCountLbl
            // 
            this.bandCountLbl.AutoSize = true;
            this.bandCountLbl.Location = new System.Drawing.Point(217, 258);
            this.bandCountLbl.Name = "bandCountLbl";
            this.bandCountLbl.Size = new System.Drawing.Size(50, 13);
            this.bandCountLbl.TabIndex = 6;
            this.bandCountLbl.Text = "Members";
            // 
            // BandFromLbl
            // 
            this.BandFromLbl.AutoSize = true;
            this.BandFromLbl.Location = new System.Drawing.Point(66, 258);
            this.BandFromLbl.Name = "BandFromLbl";
            this.BandFromLbl.Size = new System.Drawing.Size(30, 13);
            this.BandFromLbl.TabIndex = 7;
            this.BandFromLbl.Text = "From";
            this.BandFromLbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // bandInfoLbl
            // 
            this.bandInfoLbl.AutoSize = true;
            this.bandInfoLbl.Location = new System.Drawing.Point(242, 231);
            this.bandInfoLbl.Name = "bandInfoLbl";
            this.bandInfoLbl.Size = new System.Drawing.Size(25, 13);
            this.bandInfoLbl.TabIndex = 8;
            this.bandInfoLbl.Text = "Info";
            // 
            // bandInfoTbx
            // 
            this.bandInfoTbx.Location = new System.Drawing.Point(273, 228);
            this.bandInfoTbx.Name = "bandInfoTbx";
            this.bandInfoTbx.Size = new System.Drawing.Size(100, 20);
            this.bandInfoTbx.TabIndex = 9;
            // 
            // bandStartYearLbl
            // 
            this.bandStartYearLbl.AutoSize = true;
            this.bandStartYearLbl.Location = new System.Drawing.Point(86, 284);
            this.bandStartYearLbl.Name = "bandStartYearLbl";
            this.bandStartYearLbl.Size = new System.Drawing.Size(54, 13);
            this.bandStartYearLbl.TabIndex = 10;
            this.bandStartYearLbl.Text = "Start Year";
            // 
            // bandStartYearTbx
            // 
            this.bandStartYearTbx.Location = new System.Drawing.Point(146, 281);
            this.bandStartYearTbx.Name = "bandStartYearTbx";
            this.bandStartYearTbx.Size = new System.Drawing.Size(177, 20);
            this.bandStartYearTbx.TabIndex = 11;
            // 
            // BandRemoveBtn
            // 
            this.BandRemoveBtn.Location = new System.Drawing.Point(102, 368);
            this.BandRemoveBtn.Name = "BandRemoveBtn";
            this.BandRemoveBtn.Size = new System.Drawing.Size(80, 23);
            this.BandRemoveBtn.TabIndex = 12;
            this.BandRemoveBtn.Text = "Remove";
            this.BandRemoveBtn.UseVisualStyleBackColor = true;
            this.BandRemoveBtn.Click += new System.EventHandler(this.bandRemoveBtn_Click);
            // 
            // bandChangeBtn
            // 
            this.bandChangeBtn.Location = new System.Drawing.Point(16, 368);
            this.bandChangeBtn.Name = "bandChangeBtn";
            this.bandChangeBtn.Size = new System.Drawing.Size(80, 23);
            this.bandChangeBtn.TabIndex = 13;
            this.bandChangeBtn.Text = "Change";
            this.bandChangeBtn.UseVisualStyleBackColor = true;
            this.bandChangeBtn.Click += new System.EventHandler(this.bandChangeBtn_Click);
            // 
            // bandSrchTbx
            // 
            this.bandSrchTbx.Location = new System.Drawing.Point(188, 345);
            this.bandSrchTbx.Name = "bandSrchTbx";
            this.bandSrchTbx.Size = new System.Drawing.Size(177, 20);
            this.bandSrchTbx.TabIndex = 14;
            // 
            // BandSrchBtn
            // 
            this.BandSrchBtn.Location = new System.Drawing.Point(102, 342);
            this.BandSrchBtn.Name = "BandSrchBtn";
            this.BandSrchBtn.Size = new System.Drawing.Size(80, 23);
            this.BandSrchBtn.TabIndex = 15;
            this.BandSrchBtn.Text = "Search";
            this.BandSrchBtn.UseVisualStyleBackColor = true;
            this.BandSrchBtn.Click += new System.EventHandler(this.bandSrchBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 403);
            this.Controls.Add(this.BandSrchBtn);
            this.Controls.Add(this.bandSrchTbx);
            this.Controls.Add(this.bandChangeBtn);
            this.Controls.Add(this.BandRemoveBtn);
            this.Controls.Add(this.bandStartYearTbx);
            this.Controls.Add(this.bandStartYearLbl);
            this.Controls.Add(this.bandInfoTbx);
            this.Controls.Add(this.bandInfoLbl);
            this.Controls.Add(this.BandFromLbl);
            this.Controls.Add(this.bandCountLbl);
            this.Controls.Add(this.bandNameLbl);
            this.Controls.Add(this.BandFromTbx);
            this.Controls.Add(this.bandCountTbx);
            this.Controls.Add(this.bandNameTbx);
            this.Controls.Add(this.bandAddBtn);
            this.Controls.Add(this.bandDGV);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bandBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bandDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource bandBS;
        private System.Windows.Forms.DataGridView bandDGV;
        private System.Windows.Forms.Button bandAddBtn;
        private System.Windows.Forms.TextBox bandNameTbx;
        private System.Windows.Forms.TextBox bandCountTbx;
        private System.Windows.Forms.TextBox BandFromTbx;
        private System.Windows.Forms.Label bandNameLbl;
        private System.Windows.Forms.Label bandCountLbl;
        private System.Windows.Forms.Label BandFromLbl;
        private System.Windows.Forms.Label bandInfoLbl;
        private System.Windows.Forms.TextBox bandInfoTbx;
        private System.Windows.Forms.Label bandStartYearLbl;
        private System.Windows.Forms.TextBox bandStartYearTbx;
        private System.Windows.Forms.Button BandRemoveBtn;
        private System.Windows.Forms.Button bandChangeBtn;
        private System.Windows.Forms.TextBox bandSrchTbx;
        private System.Windows.Forms.Button BandSrchBtn;
    }
}

