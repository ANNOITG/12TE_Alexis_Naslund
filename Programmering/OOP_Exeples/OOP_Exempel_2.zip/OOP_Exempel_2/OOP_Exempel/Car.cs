﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Exempel
{
    class Car
    {
        public static int counter { get; set; }

        public Car()
        {
            counter++;
        }

        public string modell { get; set; }
        public string marke { get; set; }
        public int agare { get; set; }
        public string vkord { get; set; }
        public int tillar { get; set; }



        public override string ToString()
        {
            return "\n=============================" + "\nTillverkare: " + modell + "\nMärke: " + marke + "\nAntal ägare: " + agare + "\nVinterkörd: " + vkord + "\nTillverkningsår: " + tillar + "\n=============================";

        }
    }
}
