﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Exempel
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Car> myPersons = new List<Car>();

            while (true)
            {
                Console.WriteLine("======================================");
                Console.WriteLine("| Tryck A för lägga in bil           |");
                Console.WriteLine("| Tryck B för att visa inlagda bilar |");
                Console.WriteLine("| Tryck X för att avsluta            |");
                Console.WriteLine("======================================");
                string val = Console.ReadLine();

                switch (val)
                {
                    case "a":

                        Car per = new Car();
                        Console.WriteLine("====Tillverkare?====");
                        per.modell = Console.ReadLine();
                        
                        Console.WriteLine("====Modell?====");
                        per.marke = int.Parse(Console.ReadLine());

                        Console.WriteLine("====Hur många ägare?====");
                        per.agare = int.Parse(Console.ReadLine());

                        Console.WriteLine("====Vinterkörd?====");
                        per.vkord = Console.ReadLine();

                        Console.WriteLine("====Tillverkningsår?====");
                        per.tillar = int.Parse(Console.ReadLine());

                        myPersons.Add(per);

                        break;

                    case "b":
                        foreach (Car p in myPersons)
                        {
                            Console.WriteLine(p + "\n");
                        }
                            break;
                    case "x":
                            Environment.Exit(0);
                            break;

                    default:
                        Console.WriteLine("Du gjorde ett inkorrekt val.");
                        Console.Clear();
                        break; 
                }
            }
            Console.ReadKey();
        }
    }
}
