﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RekursiveAlgorithm_Exemple
{
    class Program
    {
        // 5!/2! = 5*4 = 20
        //5! = 5*4*3*2*1 = 240

        public static long Fakuletet(long tal)
        {
            if (tal > 1)
            {
                return tal * Fakuletet(tal - 1);
            }
            else
            {
                return 1;
            }
        }


        static void Main(string[] args)
        {
            Console.WriteLine(Fakuletet(10));
            Console.ReadKey();
        }
    }
}
