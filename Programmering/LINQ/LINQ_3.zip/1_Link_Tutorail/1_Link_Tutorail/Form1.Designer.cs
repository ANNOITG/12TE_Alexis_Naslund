﻿namespace _1_Link_Tutorail
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bandDGV = new System.Windows.Forms.DataGridView();
            this.bandBS = new System.Windows.Forms.BindingSource(this.components);
            this.bandAddBtn = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.bandNameTbx = new System.Windows.Forms.Label();
            this.bandCountTbx = new System.Windows.Forms.Label();
            this.BandFromTbx = new System.Windows.Forms.Label();
            this.bandInfoTbx = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.bandStartYearTbx = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.bandDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bandBS)).BeginInit();
            this.SuspendLayout();
            // 
            // bandDGV
            // 
            this.bandDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bandDGV.Location = new System.Drawing.Point(16, 30);
            this.bandDGV.Name = "bandDGV";
            this.bandDGV.Size = new System.Drawing.Size(455, 180);
            this.bandDGV.TabIndex = 0;
            // 
            // bandAddBtn
            // 
            this.bandAddBtn.Location = new System.Drawing.Point(16, 368);
            this.bandAddBtn.Name = "bandAddBtn";
            this.bandAddBtn.Size = new System.Drawing.Size(75, 23);
            this.bandAddBtn.TabIndex = 1;
            this.bandAddBtn.Text = "Save";
            this.bandAddBtn.UseVisualStyleBackColor = true;
            this.bandAddBtn.Click += new System.EventHandler(this.bandAddBtn_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(102, 228);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(273, 254);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(102, 255);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 4;
            // 
            // bandNameTbx
            // 
            this.bandNameTbx.AutoSize = true;
            this.bandNameTbx.Location = new System.Drawing.Point(37, 231);
            this.bandNameTbx.Name = "bandNameTbx";
            this.bandNameTbx.Size = new System.Drawing.Size(63, 13);
            this.bandNameTbx.TabIndex = 5;
            this.bandNameTbx.Text = "Band Namn";
            // 
            // bandCountTbx
            // 
            this.bandCountTbx.AutoSize = true;
            this.bandCountTbx.Location = new System.Drawing.Point(217, 258);
            this.bandCountTbx.Name = "bandCountTbx";
            this.bandCountTbx.Size = new System.Drawing.Size(50, 13);
            this.bandCountTbx.TabIndex = 6;
            this.bandCountTbx.Text = "Members";
            // 
            // BandFromTbx
            // 
            this.BandFromTbx.AutoSize = true;
            this.BandFromTbx.Location = new System.Drawing.Point(66, 258);
            this.BandFromTbx.Name = "BandFromTbx";
            this.BandFromTbx.Size = new System.Drawing.Size(30, 13);
            this.BandFromTbx.TabIndex = 7;
            this.BandFromTbx.Text = "From";
            this.BandFromTbx.Click += new System.EventHandler(this.label1_Click);
            // 
            // bandInfoTbx
            // 
            this.bandInfoTbx.AutoSize = true;
            this.bandInfoTbx.Location = new System.Drawing.Point(242, 231);
            this.bandInfoTbx.Name = "bandInfoTbx";
            this.bandInfoTbx.Size = new System.Drawing.Size(25, 13);
            this.bandInfoTbx.TabIndex = 8;
            this.bandInfoTbx.Text = "Info";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(273, 228);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 9;
            // 
            // bandStartYearTbx
            // 
            this.bandStartYearTbx.AutoSize = true;
            this.bandStartYearTbx.Location = new System.Drawing.Point(86, 284);
            this.bandStartYearTbx.Name = "bandStartYearTbx";
            this.bandStartYearTbx.Size = new System.Drawing.Size(54, 13);
            this.bandStartYearTbx.TabIndex = 10;
            this.bandStartYearTbx.Text = "Start Year";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(146, 281);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(177, 20);
            this.textBox5.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1108, 403);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.bandStartYearTbx);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.bandInfoTbx);
            this.Controls.Add(this.BandFromTbx);
            this.Controls.Add(this.bandCountTbx);
            this.Controls.Add(this.bandNameTbx);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.bandAddBtn);
            this.Controls.Add(this.bandDGV);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bandDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bandBS)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView bandDGV;
        private System.Windows.Forms.BindingSource bandBS;
        private System.Windows.Forms.Button bandAddBtn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label bandNameTbx;
        private System.Windows.Forms.Label bandCountTbx;
        private System.Windows.Forms.Label BandFromTbx;
        private System.Windows.Forms.Label bandInfoTbx;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label bandStartYearTbx;
        private System.Windows.Forms.TextBox textBox5;
    }
}

