﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Exempel
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Car> myPersons = new List<Car>();

            myPersons.Add(new Car() { modell = "Volvo", regnum = "OKX507", marke = "740", agare = 5, vkord = "Ja", tillar = 1989 });
            myPersons.Add(new Car() { modell = "Mazda", regnum = "PHP100", marke = "RX7", agare = 3, vkord = "Nej", tillar = 1994 });
            myPersons.Add(new Car() { modell = "Toyota", regnum = "POP500", marke = "Supra", agare = 8, vkord = "Nej", tillar = 1999 });

            while (true)
            {
                Console.WriteLine("======================================");
                Console.WriteLine("| Tryck A för lägga in bil           |");
                Console.WriteLine("| Tryck B för att visa inlagda bilar |");
                Console.WriteLine("| Tryck C för att ändra inlagd bil   |");
                Console.WriteLine("| Tryck D för att ta bort inlagd bil |");
                Console.WriteLine("| Tryck X för att avsluta            |");
                Console.WriteLine("======================================");
                string val = Console.ReadLine();

                switch (val)
                {
                    case "a"://=====================Lägg in bilar================

                        Car per = new Car();
                        Console.WriteLine("====Tillverkare?====");
                        per.modell = Console.ReadLine();

                        Console.WriteLine("====Regnummer?====");
                        per.regnum = Console.ReadLine();
                        
                        Console.WriteLine("====Modell?====");
                        per.marke = Console.ReadLine();

                        Console.WriteLine("====Hur många ägare?====");
                        per.agare = int.Parse(Console.ReadLine());

                        Console.WriteLine("====Vinterkörd?====");
                        per.vkord = Console.ReadLine();

                        Console.WriteLine("====Tillverkningsår?====");
                        per.tillar = int.Parse(Console.ReadLine());

                        myPersons.Add(per);

                        break;

                    case "b"://============================Visa alla bilar===============
                        Console.WriteLine("Antal inlagda bilar: " + Car.counter);

                        foreach (Car p in myPersons)
                        {
                            Console.WriteLine(p + "\n");
                        }
                            break;


                    case "c": // ============================Ändra i index=====================

                            Console.WriteLine("Ändra en bil i index");

                            
                            foreach (Car p in myPersons)
                            {
                                Console.WriteLine(p + "\n");
                            }
                            try
                            {

                                Console.WriteLine("Vilken regnummer vill du ta fram?"); //Istället för att söka på vilken siffra, så söker man på Regnummret.
                                string andraRegnum = Console.ReadLine();
                                Car car = myPersons.Single(p => p.regnum == andraRegnum);

                                //=========================================================================================
                                Console.WriteLine("Modell?"); //Börjar läsa om ny information om obejektet
                                car.modell = Console.ReadLine();

                                Console.WriteLine("Regnummer?"); //Börjar läsa om ny information om obejektet
                                car.regnum = Console.ReadLine();

                                Console.WriteLine("Märke?"); //Börjar läsa om ny information om obejektet
                                car.marke = Console.ReadLine();

                                Console.WriteLine("Ägare?"); //Börjar läsa om ny information om obejektet
                                car.agare = int.Parse(Console.ReadLine());

                                Console.WriteLine("Vinterkörd?"); //Börjar läsa om ny information om obejektet
                                car.vkord = Console.ReadLine();

                                Console.WriteLine("Tillverkningsår?"); //Börjar läsa om ny information om obejektet
                                car.tillar = int.Parse(Console.ReadLine());
                                //==========================================================================================
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }

                            break;

                    case "d": //=======================Ta bort bil=======================


                            Console.WriteLine("Ta bort en bil via index");
                            
                            foreach (Car p in myPersons)
                            {
                                Console.WriteLine(p + "\n");
                                
                            }
                            try
                            {
                                Console.WriteLine("Vilken bil vill du ta bort?"); //Använder samma metod som i "Sök bilar" fast man söker på reg för att ta bort.
                                string Remcar = Console.ReadLine();


                                Car carToRem = myPersons.Single(car => car.regnum == Remcar); 
                                myPersons.Remove(carToRem);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }

                            break;

                    case "e"://====================SÖK I OBJEKT==========================
                            Console.WriteLine("Skriv in sökord:");
                            string sokOrd = Console.ReadLine();

                            var sokRes = from res in myPersons
                                         where res.modell.Contains(sokOrd)
                                         || res.regnum.Contains(sokOrd)
                                         || res.marke.Contains(sokOrd)
                                         || res.agare.ToString().Contains(sokOrd)
                                         || res.vkord.Contains(sokOrd)
                                         || res.tillar.ToString().Contains(sokOrd)
                                         select res;

                            foreach (Car p in sokRes)
                            {
                                Console.WriteLine(p);
                            }
                            break;

                        //==============SLUT PÅ SÖK============================

                    case "x":
                            Environment.Exit(0);
                            break;

                    default:
                        Console.WriteLine("Du gjorde ett inkorrekt val.");
                        Console.Clear();
                        break; 
                }
            }
            
        }
    }
}
